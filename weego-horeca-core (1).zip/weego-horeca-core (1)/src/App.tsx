/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Hero } from './components/Hero';
import { Essence } from './components/Essence';
import { Architecture } from './components/Architecture';
import { Storefront } from './components/Storefront';
import { Skins } from './components/Skins';
import { Admin } from './components/Admin';
import { Payments } from './components/Payments';
import { DataModel } from './components/DataModel';
import { Reliability } from './components/Reliability';
import { Security } from './components/Security';
import { Deployment } from './components/Deployment';
import { CTA } from './components/CTA';

export default function App() {
  return (
    <div className="min-h-screen bg-graphite text-white selection:bg-amber-500/30">
      <Hero />
      <Essence />
      <Architecture />
      <Storefront />
      <Skins />
      <Admin />
      <Payments />
      <DataModel />
      <Reliability />
      <Security />
      <Deployment />
      <CTA />
    </div>
  );
}

