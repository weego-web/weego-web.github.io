import React from 'react';
import { motion } from 'motion/react';
import { Users, Package, Store, BarChart3, Target } from 'lucide-react';

export const Admin = () => {
  return (
    <section className="py-32 relative border-t border-white/10 bg-graphite">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="font-mono text-[10px] text-amber-500 uppercase tracking-widest mb-4"
          >
            05 // Marketing & Operations Center
          </motion.div>
          <h2 className="text-4xl md:text-5xl font-serif mb-6">
            Дані, що <span className="italic text-white/50">генерують прибуток</span>
          </h2>
          <p className="text-white/60 font-light leading-relaxed">
            Забудьте про сліпі зони. Ви бачите кожного клієнта, кожне замовлення та ефективність кожної філії в реальному часі. Використовуйте ці дані для точкового маркетингу.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 border border-white/10 bg-graphite-light rounded-xl p-1 overflow-hidden relative group">
            <img src="https://picsum.photos/seed/data-dashboard/1000/800?blur=4" alt="Dashboard Data" className="absolute inset-0 w-full h-full object-cover opacity-20 group-hover:opacity-30 transition-opacity duration-700" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-graphite/80" />
            
            <div className="bg-white/5 backdrop-blur-md rounded-lg border border-white/10 h-full p-6 flex flex-col relative z-10">
              <div className="flex justify-between items-center border-b border-white/10 pb-4 mb-6">
                <div className="font-mono text-sm uppercase tracking-wider flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-amber-500" />
                  Customer Insights
                </div>
                <div className="flex gap-2">
                  <div className="px-3 py-1 bg-amber-500/10 text-amber-500 text-xs font-mono rounded border border-amber-500/20 flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                    Live Sync
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-4 mb-6">
                <div className="p-4 bg-white/5 rounded border border-white/10">
                  <div className="text-[10px] font-mono text-white/50 uppercase mb-1">Customer Acquisition Cost</div>
                  <div className="text-xl font-serif">₴120 <span className="text-emerald-500 text-xs font-sans ml-1">↓ 12%</span></div>
                </div>
                <div className="p-4 bg-white/5 rounded border border-white/10">
                  <div className="text-[10px] font-mono text-white/50 uppercase mb-1">Average Order Value</div>
                  <div className="text-xl font-serif">₴850 <span className="text-emerald-500 text-xs font-sans ml-1">↑ 18%</span></div>
                </div>
                <div className="p-4 bg-white/5 rounded border border-white/10">
                  <div className="text-[10px] font-mono text-white/50 uppercase mb-1">Repeat Purchase Rate</div>
                  <div className="text-xl font-serif text-amber-500">64%</div>
                </div>
              </div>

              <div className="space-y-2 flex-1">
                <div className="text-xs font-mono text-white/40 uppercase mb-2">Recent High-Value Orders</div>
                {[
                  { id: "VIP-089", user: "Олександр М.", items: 5, total: "₴2,450", status: "Loyalty Tier: Gold" },
                  { id: "VIP-090", user: "Марія К.", items: 3, total: "₴1,820", status: "Loyalty Tier: Platinum" },
                  { id: "ORD-142", user: "Іван П.", items: 4, total: "₴1,100", status: "1st Order (Retargeting)" },
                ].map((order, i) => (
                  <div key={i} className="flex items-center justify-between p-3 border border-white/5 bg-white/[0.02] rounded hover:bg-white/[0.06] transition-colors cursor-pointer">
                    <div className="flex items-center gap-4">
                      <div className="w-8 h-8 rounded-full bg-graphite border border-white/10 flex items-center justify-center text-xs font-serif">{order.user.charAt(0)}</div>
                      <div>
                        <div className="font-mono text-xs text-white/90">{order.user}</div>
                        <div className="text-[10px] text-white/40">{order.id} • {order.items} items</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono text-white text-sm">{order.total}</div>
                      <div className="text-[10px] text-amber-500 uppercase tracking-wider">{order.status}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="flex flex-col gap-4">
            {[
              { icon: Target, title: "CRM & Сегментація", desc: "Збирайте базу, сегментуйте клієнтів за RFM-аналізом та запускайте персоналізовані акції." },
              { icon: Package, title: "Динамічне ціноутворення", desc: "Керуйте цінами та наявністю в реальному часі. A/B тестування позицій меню." },
              { icon: Store, title: "Мульти-філіальність", desc: "Аналітика по кожній точці окремо. Порівняння ефективності та оптимізація зон доставки." },
              { icon: Users, title: "Програма лояльності", desc: "Вбудована система кешбеку та рівнів лояльності для утримання клієнтів (Retention)." }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="p-5 border border-white/10 bg-white/[0.02] flex gap-4 items-start hover:bg-white/[0.05] transition-colors"
              >
                <feature.icon className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-mono text-xs uppercase tracking-wider mb-1">{feature.title}</h4>
                  <p className="text-xs text-white/50 leading-relaxed">{feature.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
