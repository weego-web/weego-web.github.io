import React from 'react';
import { motion } from 'motion/react';
import { ShoppingBag, MapPin, Clock, CreditCard } from 'lucide-react';

export const Storefront = () => {
  return (
    <section className="py-32 relative border-t border-white/10 bg-graphite">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="font-mono text-[10px] text-amber-500 uppercase tracking-widest mb-4"
          >
            03 // Conversion-Optimized Storefront
          </motion.div>
          <h2 className="text-4xl md:text-5xl font-serif mb-6">
            Дизайн, що <span className="italic text-white/50">продає більше</span>
          </h2>
          <p className="text-white/60 font-light leading-relaxed">
            Кожен елемент інтерфейсу спроектований для максимізації конверсії та середнього чеку. Вбудовані механіки апсейлу, крос-сейлу та персоналізованих рекомендацій.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: MapPin, title: "Smart Routing", desc: "Автоматичний вибір філії за гео-зоною клієнта. Зменшення відмов на етапі доставки.", step: "01", img: "https://picsum.photos/seed/map-routing/400/300" },
            { icon: ShoppingBag, title: "Upsell Menu", desc: "Алгоритмічні рекомендації до страв. Збільшення середнього чеку на 15-20%.", step: "02", img: "https://picsum.photos/seed/food-menu/400/300" },
            { icon: CreditCard, title: "1-Click Checkout", desc: "Apple Pay / Google Pay. Мінімальне тертя при оплаті підвищує конверсію.", step: "03", img: "https://picsum.photos/seed/checkout-pay/400/300" },
            { icon: Clock, title: "Retention Status", desc: "Гейміфікований трекінг замовлення з пропозиціями на наступну покупку.", step: "04", img: "https://picsum.photos/seed/delivery-status/400/300" }
          ].map((item, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative border border-white/10 bg-white/[0.02] overflow-hidden flex flex-col"
            >
              <div className="h-40 relative overflow-hidden">
                <img src={item.img} alt={item.title} className="w-full h-full object-cover opacity-50 group-hover:opacity-80 group-hover:scale-105 transition-all duration-700" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-gradient-to-t from-graphite to-transparent" />
                <div className="font-serif italic text-4xl text-white/20 absolute top-4 right-4 z-10">{item.step}</div>
              </div>
              <div className="p-6 pt-0 relative z-10 flex-1 flex flex-col">
                <div className="w-10 h-10 rounded-full bg-graphite border border-white/10 flex items-center justify-center -mt-5 mb-4 relative z-20">
                  <item.icon className="w-5 h-5 text-amber-500" />
                </div>
                <h3 className="font-mono text-sm uppercase tracking-wider mb-3">{item.title}</h3>
                <p className="text-white/50 text-sm leading-relaxed">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
