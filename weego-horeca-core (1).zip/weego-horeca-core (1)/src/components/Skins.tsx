import React from 'react';
import { motion } from 'motion/react';
import { Palette, Sparkles } from 'lucide-react';

export const Skins = () => {
  return (
    <section className="py-32 relative border-t border-white/10 bg-graphite-light/30 overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row gap-16 items-center">
          <div className="flex-1 order-2 md:order-1 relative">
            {/* Decorative background glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-amber-500/5 rounded-full blur-[80px] pointer-events-none" />
            
            <div className="grid grid-cols-2 gap-6 relative z-10">
              {/* Skin Mockup 1 - Premium Dark */}
              <motion.div 
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="aspect-[3/4] border border-white/10 bg-graphite rounded-2xl p-2 flex flex-col relative overflow-hidden shadow-2xl"
              >
                <img src="https://picsum.photos/seed/sushi-premium/600/800" alt="Premium Dark Theme" className="absolute inset-0 w-full h-full object-cover opacity-40" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/80 to-transparent" />
                
                <div className="relative z-10 flex-1 flex flex-col justify-end p-4">
                  <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md mb-4 flex items-center justify-center border border-white/20">
                    <span className="font-serif italic text-white">S</span>
                  </div>
                  <h4 className="font-serif text-2xl text-white mb-1">Sushi Master</h4>
                  <p className="font-mono text-[10px] text-white/50 uppercase tracking-widest mb-4">Midnight Skin</p>
                  <button className="w-full py-3 bg-white text-black font-medium text-sm rounded-lg">Order Now</button>
                </div>
              </motion.div>

              {/* Skin Mockup 2 - Organic Light */}
              <motion.div 
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="aspect-[3/4] border border-white/10 bg-[#f5f5f0] rounded-2xl p-2 flex flex-col relative overflow-hidden shadow-2xl mt-12"
              >
                <img src="https://picsum.photos/seed/organic-cafe/600/800" alt="Organic Light Theme" className="absolute inset-0 w-full h-full object-cover opacity-30" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#f5f5f0] via-[#f5f5f0]/80 to-transparent" />
                
                <div className="relative z-10 flex-1 flex flex-col justify-end p-4">
                  <div className="w-12 h-12 rounded-full bg-black/5 backdrop-blur-md mb-4 flex items-center justify-center border border-black/10">
                    <span className="font-sans font-bold text-black">B</span>
                  </div>
                  <h4 className="font-sans font-semibold text-2xl text-black mb-1">Bake & Brew</h4>
                  <p className="font-mono text-[10px] text-black/50 uppercase tracking-widest mb-4">Daylight Skin</p>
                  <button className="w-full py-3 bg-[#5A5A40] text-white font-medium text-sm rounded-full">View Menu</button>
                </div>
              </motion.div>
            </div>
          </div>
          
          <div className="flex-1 order-1 md:order-2">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="font-mono text-[10px] text-amber-500 uppercase tracking-widest mb-4">04 // Brand Identity</div>
              <h2 className="text-4xl md:text-5xl font-serif mb-6">
                Ваш бренд. <span className="italic text-amber-500">Ваші правила.</span>
              </h2>
              <p className="text-white/60 font-light leading-relaxed mb-8">
                Агрегатори знеособлюють ваш бренд. WeeGo повертає вам ідентичність. Наша архітектура "Skins" дозволяє адаптувати інтерфейс під будь-який візуальний стиль за лічені години, зберігаючи потужність ядра.
              </p>
              
              <div className="space-y-6">
                <div className="flex gap-4 group">
                  <div className="w-10 h-10 rounded-full border border-white/10 bg-white/5 flex items-center justify-center shrink-0 text-amber-500 group-hover:bg-amber-500 group-hover:text-graphite transition-colors">
                    <Palette className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-mono text-sm uppercase tracking-wider mb-1">Design Tokens</h4>
                    <p className="text-sm text-white/50">Кольори, типографіка, радіуси та відступи керуються через централізований конфіг. Миттєвий ребрендинг.</p>
                  </div>
                </div>
                <div className="flex gap-4 group">
                  <div className="w-10 h-10 rounded-full border border-white/10 bg-white/5 flex items-center justify-center shrink-0 text-amber-500 group-hover:bg-amber-500 group-hover:text-graphite transition-colors">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-mono text-sm uppercase tracking-wider mb-1">Premium Feel</h4>
                    <p className="text-sm text-white/50">Плавні мікроінтеракції, скелетони завантаження та оптимізовані зображення створюють відчуття дорогого продукту.</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};
