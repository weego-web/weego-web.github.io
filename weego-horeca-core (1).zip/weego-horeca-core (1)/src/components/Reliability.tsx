import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Activity, ShieldAlert, Zap } from 'lucide-react';

export const Reliability = () => {
  const [lang, setLang] = useState<'uk' | 'en'>('uk');

  const content = {
    uk: {
      badge: "08 // Reliability",
      title: "Стійкість у",
      titleHighlight: "години пік",
      desc: "П'ятниця, вечір. Сотні замовлень одночасно. Ваша система не має права на помилку. WeeGo спроектовано витримувати екстремальні навантаження без втрати швидкості.",
      uptime: "99.9% Uptime Target",
      features: [
        { title: "Миттєве завантаження", desc: "Клієнти бачать меню за мілісекунди завдяки розумному кешуванню. Більше швидкість = вища конверсія." },
        { title: "Захист від ботів", desc: "Вбудований захист від DDoS-атак та парсингу вашого меню конкурентами." },
        { title: "Ізоляція збоїв", desc: "Якщо відмовить зовнішній сервіс (наприклад, SMS), система продовжить приймати замовлення." }
      ]
    },
    en: {
      badge: "08 // Reliability",
      title: "Resilience during",
      titleHighlight: "peak hours",
      desc: "Friday night. Hundreds of orders simultaneously. Your system has no room for error. WeeGo is designed to withstand extreme loads without losing speed.",
      uptime: "99.9% Uptime Target",
      features: [
        { title: "Instant Loading", desc: "Customers see the menu in milliseconds thanks to smart caching. More speed = higher conversion." },
        { title: "Bot Protection", desc: "Built-in protection against DDoS attacks and competitors scraping your menu." },
        { title: "Failure Isolation", desc: "If an external service fails (e.g., SMS), the system will continue to accept orders." }
      ]
    }
  };

  const t = content[lang];

  return (
    <section className="py-32 relative border-t border-white/10 bg-graphite-light/30">
      {/* Language Switcher */}
      <div className="absolute top-6 right-6 z-50 flex gap-2 bg-white/5 p-1 rounded-full border border-white/10 backdrop-blur-md">
        <button 
          onClick={() => setLang('uk')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'uk' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          UK
        </button>
        <button 
          onClick={() => setLang('en')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'en' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          EN
        </button>
      </div>

      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row gap-16 items-center">
          <div className="flex-1 order-2 md:order-1">
            <div className="grid gap-4">
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="p-6 border border-white/10 bg-graphite flex gap-4 hover:bg-white/[0.02] transition-colors"
              >
                <div className="mt-1">
                  <Zap className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <h4 className="font-mono text-sm uppercase tracking-wider mb-2">{t.features[0].title}</h4>
                  <p className="text-sm text-white/50 leading-relaxed">{t.features[0].desc}</p>
                </div>
              </motion.div>
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="p-6 border border-white/10 bg-graphite flex gap-4 hover:bg-white/[0.02] transition-colors"
              >
                <div className="mt-1">
                  <Activity className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <h4 className="font-mono text-sm uppercase tracking-wider mb-2">{t.features[1].title}</h4>
                  <p className="text-sm text-white/50 leading-relaxed">{t.features[1].desc}</p>
                </div>
              </motion.div>
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="p-6 border border-white/10 bg-graphite flex gap-4 hover:bg-white/[0.02] transition-colors"
              >
                <div className="mt-1">
                  <ShieldAlert className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <h4 className="font-mono text-sm uppercase tracking-wider mb-2">{t.features[2].title}</h4>
                  <p className="text-sm text-white/50 leading-relaxed">{t.features[2].desc}</p>
                </div>
              </motion.div>
            </div>
          </div>
          
          <div className="flex-1 order-1 md:order-2">
            <div className="font-mono text-[10px] text-amber-500 uppercase tracking-widest mb-4">{t.badge}</div>
            <h2 className="text-4xl md:text-5xl font-serif mb-6">
              {t.title} <span className="italic text-amber-500">{t.titleHighlight}</span>
            </h2>
            <p className="text-white/60 font-light leading-relaxed mb-8">
              {t.desc}
            </p>
            
            <div className="inline-flex items-center gap-3 px-4 py-2 border border-emerald-500/30 bg-emerald-500/10 rounded-full text-emerald-500 font-mono text-xs">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              {t.uptime}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
