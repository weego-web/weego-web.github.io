import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Database, Users, TrendingUp, ShieldCheck } from 'lucide-react';

export const DataModel = () => {
  const [lang, setLang] = useState<'uk' | 'en'>('uk');

  const content = {
    uk: {
      badge: "07 // Data Ownership",
      title: "Ваші дані.",
      titleHighlight: "Ваш капітал.",
      desc: "На відміну від агрегаторів, які приховують контакти клієнтів, WeeGo віддає вам 100% даних. Ви володієте історією замовлень, вподобаннями та контактною інформацією кожного гостя.",
      models: [
        { name: "Customer Profiles", desc: "Контакти, дні народження, LTV", icon: Users },
        { name: "Order History", desc: "Частота, середній чек, улюблені страви", icon: TrendingUp },
        { name: "Secure Instance", desc: "Ізольована база даних лише для вас", icon: ShieldCheck }
      ],
      footer: "Дані надійно зберігаються та належать виключно вашому бізнесу."
    },
    en: {
      badge: "07 // Data Ownership",
      title: "Your Data.",
      titleHighlight: "Your Capital.",
      desc: "Unlike aggregators that hide customer contacts, WeeGo gives you 100% of the data. You own the order history, preferences, and contact information of every guest.",
      models: [
        { name: "Customer Profiles", desc: "Contacts, birthdays, LTV", icon: Users },
        { name: "Order History", desc: "Frequency, AOV, favorite items", icon: TrendingUp },
        { name: "Secure Instance", desc: "Isolated database just for you", icon: ShieldCheck }
      ],
      footer: "Data is securely stored and belongs exclusively to your business."
    }
  };

  const t = content[lang];

  return (
    <section className="py-32 relative border-t border-white/10 bg-graphite">
      {/* Language Switcher */}
      <div className="absolute top-6 right-6 z-50 flex gap-2 bg-white/5 p-1 rounded-full border border-white/10 backdrop-blur-md">
        <button 
          onClick={() => setLang('uk')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'uk' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          UK
        </button>
        <button 
          onClick={() => setLang('en')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'en' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          EN
        </button>
      </div>

      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <div className="font-mono text-[10px] text-amber-500 uppercase tracking-widest mb-4">{t.badge}</div>
          <h2 className="text-4xl md:text-5xl font-serif mb-6">
            {t.title} <span className="italic text-white/50">{t.titleHighlight}</span>
          </h2>
          <p className="text-white/60 font-light leading-relaxed">
            {t.desc}
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-3 gap-6">
            {t.models.map((model, i) => (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="p-8 border border-white/10 bg-white/[0.02] flex flex-col items-center text-center gap-4 hover:bg-white/[0.05] transition-colors group"
              >
                <div className="w-16 h-16 rounded-full bg-graphite border border-white/10 flex items-center justify-center group-hover:border-amber-500/50 transition-colors">
                  <model.icon className="w-6 h-6 text-amber-500" />
                </div>
                <div className="font-serif text-xl">{model.name}</div>
                <div className="text-sm text-white/50 leading-relaxed">{model.desc}</div>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-12 text-center text-white/30 font-mono text-xs flex items-center justify-center gap-2">
            <Database className="w-3 h-3" />
            {t.footer}
          </div>
        </div>
      </div>
    </section>
  );
};
