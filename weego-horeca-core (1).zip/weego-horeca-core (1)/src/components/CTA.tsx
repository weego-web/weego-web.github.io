import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Calculator } from 'lucide-react';

export const CTA = () => {
  const [lang, setLang] = useState<'uk' | 'en'>('uk');

  const content = {
    uk: {
      title: "Готові до",
      titleHighlight: "зростання?",
      desc: "Припиніть віддавати 30% прибутку агрегаторам. Отримайте власне цифрове ядро WeeGo HoReCa та почніть будувати прямі відносини з вашими гостями.",
      btnPrimary: "Замовити демо",
      btnSecondary: "Розрахувати ROI",
      footer: "© {year} WeeGo Digital Studio. Всі права захищено."
    },
    en: {
      title: "Ready to",
      titleHighlight: "grow?",
      desc: "Stop giving 30% of your profits to aggregators. Get your own WeeGo HoReCa digital core and start building direct relationships with your guests.",
      btnPrimary: "Request Demo",
      btnSecondary: "Calculate ROI",
      footer: "© {year} WeeGo Digital Studio. All rights reserved."
    }
  };

  const t = content[lang];

  return (
    <section className="py-32 relative border-t border-white/10 overflow-hidden">
      {/* Language Switcher */}
      <div className="absolute top-6 right-6 z-50 flex gap-2 bg-white/5 p-1 rounded-full border border-white/10 backdrop-blur-md">
        <button 
          onClick={() => setLang('uk')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'uk' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          UK
        </button>
        <button 
          onClick={() => setLang('en')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'en' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          EN
        </button>
      </div>

      <div className="absolute inset-0 bg-amber-500/5 pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-amber-500/10 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="container mx-auto px-6 relative z-10 text-center">
        <h2 className="text-5xl md:text-7xl font-serif mb-8">
          {t.title} <span className="italic text-amber-500 text-glow">{t.titleHighlight}</span>
        </h2>
        <p className="text-xl text-white/60 font-light max-w-2xl mx-auto mb-12">
          {t.desc}
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button className="px-8 py-4 bg-amber-500 text-graphite font-medium rounded-full hover:bg-amber-400 transition-colors flex items-center gap-2 w-full sm:w-auto justify-center">
            {t.btnPrimary}
            <ArrowRight className="w-4 h-4" />
          </button>
          <button className="px-8 py-4 bg-graphite text-white font-medium border border-white/10 rounded-full hover:bg-white/5 transition-colors flex items-center gap-2 w-full sm:w-auto justify-center">
            <Calculator className="w-4 h-4 text-amber-500" />
            {t.btnSecondary}
          </button>
        </div>
        
        <div className="mt-16 font-mono text-[10px] text-white/40 uppercase tracking-widest">
          {t.footer.replace('{year}', new Date().getFullYear().toString())}
        </div>
      </div>
    </section>
  );
};
