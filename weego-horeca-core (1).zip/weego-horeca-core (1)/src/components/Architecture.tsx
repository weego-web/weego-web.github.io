import React, { useState } from 'react';
import { motion } from 'motion/react';

export const Architecture = () => {
  const [lang, setLang] = useState<'uk' | 'en'>('uk');

  const content = {
    uk: {
      badge: "02 // Business Architecture",
      title: "Екосистема для",
      titleHighlight: "Масштабування",
      desc: "WeeGo — це не просто сайт. Це повноцінна інфраструктура, яка об'єднує клієнтський досвід, маркетинг та операційну діяльність в єдиний механізм, що працює на збільшення вашого прибутку.",
      points: [
        "Storefront: Залучення та конверсія",
        "CRM & Marketing: Утримання та LTV",
        "Operations: Швидкість та надійність"
      ],
      diagram: {
        client: "Клієнтський Додаток",
        admin: "Маркетинг Панель",
        core: "WeeGo Core",
        coreSub: "Дані & Логіка",
        crm: "CRM",
        loyalty: "Лояльність",
        analytics: "Аналітика"
      }
    },
    en: {
      badge: "02 // Business Architecture",
      title: "Ecosystem for",
      titleHighlight: "Scaling",
      desc: "WeeGo is not just a website. It's a complete infrastructure that unites customer experience, marketing, and operations into a single mechanism working to increase your profit.",
      points: [
        "Storefront: Acquisition & Conversion",
        "CRM & Marketing: Retention & LTV",
        "Operations: Speed & Reliability"
      ],
      diagram: {
        client: "Customer App",
        admin: "Marketing Panel",
        core: "WeeGo Core",
        coreSub: "Data & Logic",
        crm: "CRM",
        loyalty: "Loyalty",
        analytics: "Analytics"
      }
    }
  };

  const t = content[lang];

  return (
    <section className="py-32 relative border-t border-white/10 overflow-hidden">
      <div className="absolute inset-0 bg-grid pointer-events-none opacity-50" />
      
      {/* Language Switcher */}
      <div className="absolute top-6 right-6 z-50 flex gap-2 bg-white/5 p-1 rounded-full border border-white/10 backdrop-blur-md">
        <button 
          onClick={() => setLang('uk')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'uk' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          UK
        </button>
        <button 
          onClick={() => setLang('en')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'en' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          EN
        </button>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row gap-16 items-center">
          <div className="flex-1">
            <div className="font-mono text-[10px] text-amber-500 uppercase tracking-widest mb-4">{t.badge}</div>
            <h2 className="text-4xl md:text-5xl font-serif mb-6">
              {t.title} <span className="italic text-amber-500">{t.titleHighlight}</span>
            </h2>
            <p className="text-white/60 font-light leading-relaxed mb-8">
              {t.desc}
            </p>
            
            <ul className="space-y-4 font-mono text-xs text-white/70">
              {t.points.map((point, i) => (
                <li key={i} className="flex items-center gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  {point}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="flex-1 w-full">
            <div className="p-8 border border-white/10 bg-graphite-light rounded-xl relative">
              {/* Diagram Mockup */}
              <div className="flex flex-col gap-8">
                {/* Client Layer */}
                <div className="flex justify-center gap-4">
                  <div className="px-6 py-3 border border-white/20 bg-white/5 rounded text-sm font-mono text-center w-40">{t.diagram.client}</div>
                  <div className="px-6 py-3 border border-white/20 bg-white/5 rounded text-sm font-mono text-center w-40">{t.diagram.admin}</div>
                </div>
                
                {/* Arrows */}
                <div className="flex justify-center gap-20 relative h-8">
                  <div className="absolute top-0 bottom-0 w-px bg-gradient-to-b from-white/20 to-amber-500/50 left-[calc(50%-5rem)]" />
                  <div className="absolute top-0 bottom-0 w-px bg-gradient-to-b from-white/20 to-amber-500/50 right-[calc(50%-5rem)]" />
                </div>
                
                {/* BFF Layer */}
                <div className="flex justify-center">
                  <div className="px-8 py-4 border border-amber-500/50 bg-amber-500/10 rounded-lg text-center w-64 glow-amber relative">
                    <div className="font-mono text-amber-500 font-bold mb-1">{t.diagram.core}</div>
                    <div className="text-[10px] text-amber-500/70 uppercase tracking-widest">{t.diagram.coreSub}</div>
                  </div>
                </div>
                
                {/* Arrows */}
                <div className="flex justify-center gap-16 relative h-8">
                  <div className="absolute top-0 bottom-0 w-px bg-gradient-to-b from-amber-500/50 to-white/20 left-[calc(50%-3rem)]" />
                  <div className="absolute top-0 bottom-0 w-px bg-gradient-to-b from-amber-500/50 to-white/20 right-[calc(50%-3rem)]" />
                </div>
                
                {/* Data Layer */}
                <div className="flex justify-center gap-6">
                  <div className="px-6 py-4 border border-white/20 bg-white/5 rounded text-center w-32">
                    <div className="font-mono text-sm mb-1">{t.diagram.crm}</div>
                  </div>
                  <div className="px-6 py-4 border border-white/20 bg-white/5 rounded text-center w-32">
                    <div className="font-mono text-sm mb-1">{t.diagram.loyalty}</div>
                  </div>
                  <div className="px-6 py-4 border border-white/20 bg-white/5 rounded text-center w-32">
                    <div className="font-mono text-sm mb-1">{t.diagram.analytics}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
