import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Smartphone, LayoutDashboard, Target } from 'lucide-react';

export const Essence = () => {
  const [lang, setLang] = useState<'uk' | 'en'>('uk');

  const content = {
    uk: {
      badge: "01 // Value Proposition",
      title: "Ваш бренд.",
      subtitle: "Ваші правила.",
      desc: "Агрегатори забирають 30% прибутку та приховують дані клієнтів. WeeGo повертає вам контроль. Це не просто додаток — це повноцінна екосистема для залучення та утримання гостей.",
      pillars: [
        {
          icon: Smartphone,
          title: "Premium Storefront",
          desc: "Додаток, що продає. Вбудовані механіки апсейлу, персоналізовані рекомендації та гейміфікація для збільшення середнього чеку.",
          tags: ["Conversion Rate", "AOV", "Retention"]
        },
        {
          icon: Target,
          title: "Marketing Engine",
          desc: "Сегментуйте аудиторію за RFM-аналізом. Запускайте тригерні push-кампанії: 'Давно не були', 'Знижка на день народження'.",
          tags: ["Push Notifications", "RFM", "Loyalty"]
        },
        {
          icon: LayoutDashboard,
          title: "Data Ownership",
          desc: "Кожен номер телефону, кожне замовлення — належить вам. Аналізуйте CAC (вартість залучення) та LTV (пожиттєву цінність).",
          tags: ["Customer Data", "LTV", "CAC"]
        }
      ]
    },
    en: {
      badge: "01 // Value Proposition",
      title: "Your Brand.",
      subtitle: "Your Rules.",
      desc: "Aggregators take 30% of your profit and hide customer data. WeeGo gives you back control. It's not just an app — it's a complete ecosystem for acquiring and retaining guests.",
      pillars: [
        {
          icon: Smartphone,
          title: "Premium Storefront",
          desc: "An app that sells. Built-in upsell mechanics, personalized recommendations, and gamification to increase average order value.",
          tags: ["Conversion Rate", "AOV", "Retention"]
        },
        {
          icon: Target,
          title: "Marketing Engine",
          desc: "Segment your audience using RFM analysis. Launch triggered push campaigns: 'We miss you', 'Birthday discount'.",
          tags: ["Push Notifications", "RFM", "Loyalty"]
        },
        {
          icon: LayoutDashboard,
          title: "Data Ownership",
          desc: "Every phone number, every order — belongs to you. Analyze CAC (Customer Acquisition Cost) and LTV (Lifetime Value).",
          tags: ["Customer Data", "LTV", "CAC"]
        }
      ]
    }
  };

  const t = content[lang];

  return (
    <section className="py-32 relative border-t border-white/10 bg-graphite-light/50">
      {/* Language Switcher */}
      <div className="absolute top-6 right-6 z-50 flex gap-2 bg-white/5 p-1 rounded-full border border-white/10 backdrop-blur-md">
        <button 
          onClick={() => setLang('uk')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'uk' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          UK
        </button>
        <button 
          onClick={() => setLang('en')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'en' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          EN
        </button>
      </div>

      <div className="container mx-auto px-6">
        <div className="max-w-3xl mb-20">
          <div className="font-mono text-[10px] text-amber-500 uppercase tracking-widest mb-4">{t.badge}</div>
          <h2 className="text-4xl md:text-5xl font-serif mb-6">
            {t.title} <span className="italic text-white/50">{t.subtitle}</span>
          </h2>
          <p className="text-lg text-white/60 font-light leading-relaxed">
            {t.desc}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {t.pillars.map((pillar, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-8 border border-white/10 bg-graphite hover:bg-white/[0.02] transition-colors group relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <pillar.icon className="w-24 h-24 text-amber-500" />
              </div>
              <div className="w-12 h-12 border border-white/10 rounded-full flex items-center justify-center mb-6 bg-white/5 text-amber-500 relative z-10">
                <pillar.icon className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-medium mb-4 relative z-10">{pillar.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed mb-8 relative z-10">
                {pillar.desc}
              </p>
              <div className="flex flex-wrap gap-2 relative z-10">
                {pillar.tags.map(tag => (
                  <span key={tag} className="px-2 py-1 border border-white/10 bg-white/5 text-[10px] font-mono uppercase tracking-wider text-white/70">
                    {tag}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
