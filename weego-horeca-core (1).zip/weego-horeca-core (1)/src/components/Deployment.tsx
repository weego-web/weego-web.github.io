import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Box, Cloud, Shield, Server, Zap, Lock } from 'lucide-react';

export const Deployment = () => {
  const [lang, setLang] = useState<'uk' | 'en'>('uk');

  const content = {
    uk: {
      badge: "10 // Single-Instance Architecture",
      title: "Ваш власний",
      titleHighlight: "сервер",
      desc: "Більшість SaaS-рішень тримають усіх клієнтів в одній базі. Якщо падає один — падають усі. WeeGo розгортає окрему, ізольовану інфраструктуру персонально для вашого бізнесу.",
      features: [
        { title: "Ізоляція навантаження", desc: "Чужі рекламні кампанії не сповільнять ваш сайт. Ви маєте виділені ресурси.", icon: Box },
        { title: "Глобальна доступність", desc: "Сервери розміщуються максимально близько до ваших клієнтів для миттєвого завантаження.", icon: Cloud },
        { title: "Повний контроль", desc: "Можливість розгортання на ваших власних серверах (On-Premise) для максимальної безпеки.", icon: Shield }
      ],
      diagram: {
        center: "Ваш Бізнес",
        centerSub: "Ізольовано",
        nodes: ["Storefront", "Database", "Admin", "Cache"]
      }
    },
    en: {
      badge: "10 // Single-Instance Architecture",
      title: "Your Dedicated",
      titleHighlight: "Server",
      desc: "Most SaaS solutions keep all clients in one database. If one goes down, everyone goes down. WeeGo deploys a separate, isolated infrastructure personally for your business.",
      features: [
        { title: "Load Isolation", desc: "Other people's ad campaigns won't slow down your site. You have dedicated resources.", icon: Box },
        { title: "Global Availability", desc: "Servers are located as close to your customers as possible for instant loading.", icon: Cloud },
        { title: "Full Control", desc: "Option to deploy on your own servers (On-Premise) for maximum security.", icon: Shield }
      ],
      diagram: {
        center: "Your Business",
        centerSub: "Isolated",
        nodes: ["Storefront", "Database", "Admin", "Cache"]
      }
    }
  };

  const t = content[lang];

  return (
    <section className="py-32 relative border-t border-white/10 bg-graphite-light/50 overflow-hidden">
      {/* Language Switcher */}
      <div className="absolute top-6 right-6 z-50 flex gap-2 bg-white/5 p-1 rounded-full border border-white/10 backdrop-blur-md">
        <button 
          onClick={() => setLang('uk')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'uk' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          UK
        </button>
        <button 
          onClick={() => setLang('en')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'en' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          EN
        </button>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row gap-16 items-center">
          <div className="flex-1">
            <div className="font-mono text-[10px] text-amber-500 uppercase tracking-widest mb-4">{t.badge}</div>
            <h2 className="text-4xl md:text-5xl font-serif mb-6">
              {t.title} <span className="italic text-amber-500">{t.titleHighlight}</span>
            </h2>
            <p className="text-white/60 font-light leading-relaxed mb-8">
              {t.desc}
            </p>
            
            <ul className="space-y-6">
              {t.features.map((feature, i) => (
                <motion.li 
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="flex gap-4 group"
                >
                  <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center shrink-0 group-hover:bg-amber-500/10 group-hover:border-amber-500/30 transition-colors">
                    <feature.icon className="w-5 h-5 text-amber-500" />
                  </div>
                  <div>
                    <div className="font-mono text-sm uppercase tracking-wider mb-1 text-white group-hover:text-amber-500 transition-colors">{feature.title}</div>
                    <div className="text-sm text-white/50 leading-relaxed">{feature.desc}</div>
                  </div>
                </motion.li>
              ))}
            </ul>
          </div>
          
          <div className="flex-1 w-full relative">
            {/* Background glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-amber-500/5 rounded-full blur-[100px] pointer-events-none" />
            
            <div className="aspect-square max-w-md mx-auto relative">
              {/* Outer orbit */}
              <div className="absolute inset-0 border border-white/10 rounded-full border-dashed animate-[spin_60s_linear_infinite]" />
              {/* Inner orbit */}
              <div className="absolute inset-12 border border-amber-500/20 rounded-full border-dashed animate-[spin_40s_linear_infinite_reverse]" />
              
              {/* Center Core */}
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div 
                  initial={{ scale: 0.8, opacity: 0 }}
                  whileInView={{ scale: 1, opacity: 1 }}
                  viewport={{ once: true }}
                  className="w-40 h-40 bg-graphite border border-amber-500/50 rounded-full flex flex-col items-center justify-center glow-amber z-10 relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-tr from-amber-500/10 to-transparent" />
                  <Server className="w-8 h-8 text-amber-500 mb-2" />
                  <div className="text-center relative z-10">
                    <div className="font-serif text-lg text-white">{t.diagram.center}</div>
                    <div className="text-[10px] text-amber-500 font-mono uppercase tracking-widest mt-1 flex items-center justify-center gap-1">
                      <Lock className="w-3 h-3" />
                      {t.diagram.centerSub}
                    </div>
                  </div>
                </motion.div>
              </div>
              
              {/* Orbiting nodes */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-graphite border border-white/20 rounded-full flex items-center justify-center z-20 shadow-xl backdrop-blur-md">
                <span className="text-xs font-mono text-white/70">{t.diagram.nodes[0]}</span>
              </div>
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-20 h-20 bg-graphite border border-white/20 rounded-full flex items-center justify-center z-20 shadow-xl backdrop-blur-md">
                <span className="text-xs font-mono text-white/70">{t.diagram.nodes[1]}</span>
              </div>
              <div className="absolute left-0 top-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-graphite border border-white/20 rounded-full flex items-center justify-center z-20 shadow-xl backdrop-blur-md">
                <span className="text-xs font-mono text-white/70">{t.diagram.nodes[2]}</span>
              </div>
              <div className="absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-graphite border border-white/20 rounded-full flex items-center justify-center z-20 shadow-xl backdrop-blur-md">
                <span className="text-xs font-mono text-white/70">{t.diagram.nodes[3]}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
