import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Lock, Eye, Key, ShieldCheck } from 'lucide-react';

export const Security = () => {
  const [lang, setLang] = useState<'uk' | 'en'>('uk');

  const content = {
    uk: {
      badge: "09 // Security & Control",
      title: "Безпека та",
      titleHighlight: "контроль",
      desc: "Ваш бізнес — ваші правила. Ми забезпечуємо банківський рівень захисту даних та повний контроль над тим, хто має доступ до вашої системи.",
      features: [
        { title: "Захист даних", desc: "Шифрування клієнтської бази та транзакцій. Ваші дані ніколи не потраплять до конкурентів.", icon: Lock },
        { title: "Контроль доступу", desc: "Різні рівні доступу для власника, маркетолога та касира. Ви контролюєте кожну дію.", icon: Key },
        { title: "Моніторинг 24/7", desc: "Автоматичне відстеження аномалій та спроб злому. Миттєве сповіщення про підозрілу активність.", icon: Eye }
      ]
    },
    en: {
      badge: "09 // Security & Control",
      title: "Security &",
      titleHighlight: "Control",
      desc: "Your business — your rules. We provide bank-level data protection and full control over who has access to your system.",
      features: [
        { title: "Data Protection", desc: "Encryption of customer base and transactions. Your data will never fall into competitors' hands.", icon: Lock },
        { title: "Access Control", desc: "Different access levels for owner, marketer, and cashier. You control every action.", icon: Key },
        { title: "24/7 Monitoring", desc: "Automatic tracking of anomalies and hacking attempts. Instant alerts on suspicious activity.", icon: Eye }
      ]
    }
  };

  const t = content[lang];

  return (
    <section className="py-32 relative border-t border-white/10 bg-graphite">
      {/* Language Switcher */}
      <div className="absolute top-6 right-6 z-50 flex gap-2 bg-white/5 p-1 rounded-full border border-white/10 backdrop-blur-md">
        <button 
          onClick={() => setLang('uk')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'uk' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          UK
        </button>
        <button 
          onClick={() => setLang('en')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'en' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          EN
        </button>
      </div>

      <div className="container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <div className="font-mono text-[10px] text-amber-500 uppercase tracking-widest mb-4">{t.badge}</div>
          <h2 className="text-4xl md:text-5xl font-serif mb-6">
            {t.title} <span className="italic text-white/50">{t.titleHighlight}</span>
          </h2>
          <p className="text-white/60 font-light leading-relaxed">
            {t.desc}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {t.features.map((feature, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="border border-white/10 p-8 bg-white/[0.02] text-center hover:bg-white/[0.05] transition-colors group"
            >
              <div className="w-12 h-12 mx-auto border border-white/10 rounded-full flex items-center justify-center bg-graphite mb-6 group-hover:border-amber-500/50 transition-colors">
                <feature.icon className="w-5 h-5 text-amber-500" />
              </div>
              <h4 className="font-mono text-sm uppercase tracking-wider mb-3">{feature.title}</h4>
              <p className="text-sm text-white/50 leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
