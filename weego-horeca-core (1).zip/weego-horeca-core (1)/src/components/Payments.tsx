import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRightLeft, ShieldCheck, RefreshCw, Smartphone, CreditCard, Server, CheckCircle2 } from 'lucide-react';

export const Payments = () => {
  const [lang, setLang] = useState<'uk' | 'en'>('uk');

  const content = {
    uk: {
      badge: "06 // Payments Infrastructure",
      title: "Жодного втраченого",
      titleHighlight: "замовлення",
      desc: "Платежі — найкритичніша частина системи. Ми побудували банківський рівень надійності: захист від подвійних списань, миттєва обробка та автоматичні повторні спроби при збоях мережі.",
      features: [
        { title: "Idempotency", desc: "Захист від подвійних списань. Кожна транзакція обробляється рівно один раз." },
        { title: "Webhook Ingest", desc: "Швидкий прийом вебхуків від платіжних шлюзів з подальшою асинхронною обробкою." },
        { title: "Resync & Queues", desc: "Автоматичні повторні спроби при збоях мережі та фонова синхронізація статусів." }
      ],
      flow: {
        step1: "Клієнт оплачує",
        step1Sub: "Apple Pay / Google Pay",
        step2: "Платіжний шлюз",
        step2Sub: "Stripe / LiqPay",
        step3: "WeeGo Core",
        step3Sub: "Перевірка безпеки",
        step4: "Замовлення прийнято",
        step4Sub: "Кухня отримує чек"
      }
    },
    en: {
      badge: "06 // Payments Infrastructure",
      title: "Never lose an",
      titleHighlight: "order",
      desc: "Payments are the most critical part of the system. We built bank-level reliability: protection against double charges, instant processing, and automatic retries during network failures.",
      features: [
        { title: "Idempotency", desc: "Protection against double charges. Every transaction is processed exactly once." },
        { title: "Webhook Ingest", desc: "Fast webhook reception from payment gateways with subsequent asynchronous processing." },
        { title: "Resync & Queues", desc: "Automatic retries during network failures and background status synchronization." }
      ],
      flow: {
        step1: "Customer Pays",
        step1Sub: "Apple Pay / Google Pay",
        step2: "Payment Gateway",
        step2Sub: "Stripe / LiqPay",
        step3: "WeeGo Core",
        step3Sub: "Security Check",
        step4: "Order Confirmed",
        step4Sub: "Kitchen receives ticket"
      }
    }
  };

  const t = content[lang];

  return (
    <section className="py-32 relative border-t border-white/10 bg-graphite-light/50 overflow-hidden">
      {/* Language Switcher */}
      <div className="absolute top-6 right-6 z-50 flex gap-2 bg-white/5 p-1 rounded-full border border-white/10 backdrop-blur-md">
        <button 
          onClick={() => setLang('uk')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'uk' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          UK
        </button>
        <button 
          onClick={() => setLang('en')}
          className={`px-3 py-1 text-xs font-mono rounded-full transition-colors ${lang === 'en' ? 'bg-amber-500 text-graphite' : 'text-white/50 hover:text-white'}`}
        >
          EN
        </button>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="flex flex-col md:flex-row gap-16 items-center">
          <div className="flex-1">
            <div className="font-mono text-[10px] text-amber-500 uppercase tracking-widest mb-4">{t.badge}</div>
            <h2 className="text-4xl md:text-5xl font-serif mb-6">
              {t.title} <span className="italic text-amber-500">{t.titleHighlight}</span>
            </h2>
            <p className="text-white/60 font-light leading-relaxed mb-8">
              {t.desc}
            </p>
            
            <div className="grid sm:grid-cols-2 gap-6">
              <div className="border border-white/10 p-4 bg-graphite hover:bg-white/[0.02] transition-colors">
                <ShieldCheck className="w-5 h-5 text-amber-500 mb-3" />
                <h4 className="font-mono text-xs uppercase tracking-wider mb-2">{t.features[0].title}</h4>
                <p className="text-xs text-white/50">{t.features[0].desc}</p>
              </div>
              <div className="border border-white/10 p-4 bg-graphite hover:bg-white/[0.02] transition-colors">
                <ArrowRightLeft className="w-5 h-5 text-amber-500 mb-3" />
                <h4 className="font-mono text-xs uppercase tracking-wider mb-2">{t.features[1].title}</h4>
                <p className="text-xs text-white/50">{t.features[1].desc}</p>
              </div>
              <div className="border border-white/10 p-4 bg-graphite sm:col-span-2 flex gap-4 items-center hover:bg-white/[0.02] transition-colors">
                <RefreshCw className="w-5 h-5 text-amber-500 shrink-0" />
                <div>
                  <h4 className="font-mono text-xs uppercase tracking-wider mb-1">{t.features[2].title}</h4>
                  <p className="text-xs text-white/50">{t.features[2].desc}</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex-1 w-full relative">
            {/* Background glow for the flow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-amber-500/10 rounded-full blur-[80px] pointer-events-none" />
            
            <div className="relative z-10 flex flex-col gap-4 max-w-md mx-auto">
              {/* Step 1 */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="flex items-center gap-4 bg-white/5 border border-white/10 p-4 rounded-xl backdrop-blur-md"
              >
                <div className="w-12 h-12 rounded-full bg-graphite border border-white/10 flex items-center justify-center shrink-0">
                  <Smartphone className="w-5 h-5 text-white/70" />
                </div>
                <div>
                  <div className="font-medium text-white">{t.flow.step1}</div>
                  <div className="text-xs text-white/50 font-mono mt-1">{t.flow.step1Sub}</div>
                </div>
              </motion.div>

              {/* Connector */}
              <div className="w-0.5 h-6 bg-gradient-to-b from-white/20 to-amber-500/50 ml-10" />

              {/* Step 2 */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="flex items-center gap-4 bg-white/5 border border-white/10 p-4 rounded-xl backdrop-blur-md"
              >
                <div className="w-12 h-12 rounded-full bg-graphite border border-white/10 flex items-center justify-center shrink-0">
                  <CreditCard className="w-5 h-5 text-white/70" />
                </div>
                <div>
                  <div className="font-medium text-white">{t.flow.step2}</div>
                  <div className="text-xs text-white/50 font-mono mt-1">{t.flow.step2Sub}</div>
                </div>
              </motion.div>

              {/* Connector */}
              <div className="w-0.5 h-6 bg-gradient-to-b from-amber-500/50 to-amber-500 ml-10" />

              {/* Step 3 (Core) */}
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="flex items-center gap-4 bg-amber-500/10 border border-amber-500/30 p-5 rounded-xl backdrop-blur-md glow-amber relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-amber-500/0 via-amber-500/10 to-amber-500/0 translate-x-[-100%] animate-[shimmer_2s_infinite]" />
                <div className="w-12 h-12 rounded-full bg-amber-500/20 border border-amber-500/50 flex items-center justify-center shrink-0 text-amber-500">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-medium text-amber-500">{t.flow.step3}</div>
                  <div className="text-xs text-amber-500/70 font-mono mt-1 flex items-center gap-2">
                    <ShieldCheck className="w-3 h-3" />
                    {t.flow.step3Sub}
                  </div>
                </div>
              </motion.div>

              {/* Connector */}
              <div className="w-0.5 h-6 bg-gradient-to-b from-amber-500 to-emerald-500/50 ml-10" />

              {/* Step 4 */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
                className="flex items-center gap-4 bg-white/5 border border-white/10 p-4 rounded-xl backdrop-blur-md"
              >
                <div className="w-12 h-12 rounded-full bg-graphite border border-emerald-500/30 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                </div>
                <div>
                  <div className="font-medium text-white">{t.flow.step4}</div>
                  <div className="text-xs text-emerald-500/70 font-mono mt-1">{t.flow.step4Sub}</div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
