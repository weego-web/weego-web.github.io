import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Server, Database, Zap, LayoutTemplate, TrendingUp, Users, Percent } from 'lucide-react';

export const Hero = () => {
  const titleText = "WeeGo ";
  const titleHighlight = "HoReCa";

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden">
      <div className="absolute inset-0 bg-grid pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-amber-500/10 rounded-full blur-[120px] pointer-events-none" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-amber-500/30 bg-amber-500/10 text-amber-500 font-mono text-[10px] uppercase tracking-widest mb-8"
          >
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
            Stop paying 30% to aggregators
          </motion.div>
          
          <h1 className="text-6xl md:text-8xl font-serif mb-6 leading-tight flex justify-center flex-wrap">
            {titleText.split('').map((char, i) => (
              <motion.span 
                key={i} 
                initial={{ opacity: 0, y: 40 }} 
                animate={{ opacity: 1, y: 0 }} 
                transition={{ delay: i * 0.05, type: "spring", stiffness: 100 }}
              >
                {char === " " ? "\u00A0" : char}
              </motion.span>
            ))}
            <motion.span 
              initial={{ opacity: 0, filter: 'blur(20px)', scale: 0.8 }} 
              animate={{ opacity: 1, filter: 'blur(0px)', scale: 1 }} 
              transition={{ delay: 0.4, duration: 0.8, ease: "easeOut" }} 
              className="italic text-amber-500 text-glow"
            >
              {titleHighlight}
            </motion.span>
          </h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="text-lg md:text-xl text-white/60 font-light max-w-2xl mx-auto mb-12 leading-relaxed"
          >
            Власний цифровий канал продажів. Збільшуйте <strong className="text-white font-medium">LTV</strong>, керуйте даними клієнтів та запускайте маркетинг на базі власного <strong className="text-white font-medium">Single-Instance</strong> ядра.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <button className="px-8 py-4 bg-amber-500 text-graphite font-medium rounded-none hover:bg-amber-400 transition-colors flex items-center gap-2 w-full sm:w-auto justify-center group">
              Розрахувати ROI
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="px-8 py-4 bg-white/5 text-white font-medium border border-white/10 hover:bg-white/10 transition-colors w-full sm:w-auto justify-center">
              Дивитись демо
            </button>
          </motion.div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 1, type: "spring" }}
          className="mt-24 relative mx-auto max-w-5xl"
        >
          <div className="aspect-[16/9] bg-graphite-light border border-white/10 rounded-xl overflow-hidden glow-amber relative group">
            <img src="https://picsum.photos/seed/restaurant-tech/1200/800?blur=2" alt="Dashboard Background" className="absolute inset-0 w-full h-full object-cover opacity-30 group-hover:opacity-40 transition-opacity duration-700" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-gradient-to-t from-graphite via-graphite/50 to-transparent" />
            
            <div className="absolute top-0 inset-x-0 h-8 border-b border-white/10 bg-white/5 flex items-center px-4 gap-2 backdrop-blur-md">
              <div className="w-2.5 h-2.5 rounded-full bg-white/20" />
              <div className="w-2.5 h-2.5 rounded-full bg-white/20" />
              <div className="w-2.5 h-2.5 rounded-full bg-white/20" />
              <div className="ml-4 font-mono text-[10px] text-white/40 uppercase tracking-wider">weego-admin-production.fly.dev</div>
            </div>
            
            <div className="p-8 pt-16 h-full flex flex-col relative z-10">
              <div className="flex gap-6 h-full">
                {/* Sidebar mock */}
                <div className="w-48 border-r border-white/10 flex flex-col gap-4 pr-6">
                  <div className="h-8 rounded bg-amber-500/20 border border-amber-500/30 flex items-center px-3 gap-2 text-amber-500 font-mono text-xs"><TrendingUp className="w-3 h-3"/> Analytics</div>
                  <div className="h-8 rounded bg-white/5 flex items-center px-3 gap-2 text-white/50 font-mono text-xs"><Users className="w-3 h-3"/> CRM</div>
                  <div className="h-8 rounded bg-white/5 flex items-center px-3 gap-2 text-white/50 font-mono text-xs"><Percent className="w-3 h-3"/> Marketing</div>
                </div>
                {/* Content mock */}
                <div className="flex-1 flex flex-col gap-6">
                  <div className="flex gap-4">
                    <div className="h-24 flex-1 bg-white/10 backdrop-blur-md rounded border border-white/20 p-4 flex flex-col justify-between">
                      <div className="text-white/50 font-mono text-[10px] uppercase">Monthly Revenue</div>
                      <div className="text-2xl font-serif">₴1,240,500 <span className="text-emerald-500 text-sm font-sans ml-2">+14%</span></div>
                    </div>
                    <div className="h-24 flex-1 bg-white/10 backdrop-blur-md rounded border border-white/20 p-4 flex flex-col justify-between">
                      <div className="text-white/50 font-mono text-[10px] uppercase">Saved on Commissions</div>
                      <div className="text-2xl font-serif text-amber-500">₴372,150</div>
                    </div>
                    <div className="h-24 flex-1 bg-white/10 backdrop-blur-md rounded border border-white/20 p-4 flex flex-col justify-between">
                      <div className="text-white/50 font-mono text-[10px] uppercase">Active Loyalty Users</div>
                      <div className="text-2xl font-serif">4,892</div>
                    </div>
                  </div>
                  <div className="flex-1 bg-white/10 backdrop-blur-md rounded border border-white/20 p-6 relative overflow-hidden">
                    <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-amber-500/20 to-transparent opacity-50" />
                    {/* Mock Chart lines */}
                    <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none" viewBox="0 0 100 100">
                      <path d="M0,100 L0,80 Q25,60 50,70 T100,30 L100,100 Z" fill="rgba(245, 166, 35, 0.1)" />
                      <path d="M0,80 Q25,60 50,70 T100,30" fill="none" stroke="#F5A623" strokeWidth="0.5" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Floating Mobile Mockup */}
          <motion.div 
            animate={{ y: [0, -10, 0] }}
            transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
            className="absolute -right-8 -bottom-12 w-64 h-[500px] bg-graphite border border-white/20 rounded-[2rem] shadow-2xl overflow-hidden hidden lg:block"
          >
            <img src="https://picsum.photos/seed/food-delivery-app/600/1200" alt="Mobile App" className="absolute inset-0 w-full h-full object-cover opacity-50" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-gradient-to-b from-graphite/40 via-transparent to-graphite" />
            
            <div className="absolute top-0 inset-x-0 h-6 bg-black flex justify-center items-end pb-1 z-20">
              <div className="w-20 h-4 bg-graphite rounded-b-xl" />
            </div>
            
            <div className="p-4 pt-12 h-full flex flex-col gap-4 relative z-10">
              <div className="h-32 bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-4 flex flex-col justify-end">
                <div className="text-white font-serif text-lg">Special Offer</div>
                <div className="text-amber-500 font-mono text-xs">20% OFF TODAY</div>
              </div>
              <div className="flex gap-2">
                <div className="h-10 w-20 bg-amber-500 text-graphite font-medium text-xs flex items-center justify-center rounded-full">Order</div>
                <div className="h-10 flex-1 bg-white/10 backdrop-blur-md rounded-full flex items-center px-4 text-white/50 text-xs">Search menu...</div>
              </div>
              <div className="flex-1 bg-white/10 backdrop-blur-md rounded-xl border border-white/20 p-4">
                <div className="w-full h-24 bg-white/5 rounded-lg mb-3" />
                <div className="w-3/4 h-4 bg-white/20 rounded mb-2" />
                <div className="w-1/2 h-4 bg-white/10 rounded" />
              </div>
            </div>
          </motion.div>
        </motion.div>

        <div className="mt-32 grid grid-cols-2 md:grid-cols-4 gap-8 border-t border-white/10 pt-12">
          {[
            { icon: Server, label: "Власний сервер", desc: "Дані належать тільки вам" },
            { icon: Database, label: "CRM & Аналітика", desc: "Глибоке розуміння клієнта" },
            { icon: Zap, label: "Push-маркетинг", desc: "Безкоштовні комунікації" },
            { icon: LayoutTemplate, label: "White-label", desc: "100% ваш брендинг" }
          ].map((tech, i) => (
            <div key={i} className="flex flex-col items-center text-center gap-3">
              <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-amber-500">
                <tech.icon className="w-5 h-5" />
              </div>
              <div>
                <div className="font-mono text-xs uppercase tracking-wider text-white">{tech.label}</div>
                <div className="text-sm text-white/40 mt-1">{tech.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
